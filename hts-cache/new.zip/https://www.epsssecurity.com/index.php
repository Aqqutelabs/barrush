
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/main.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<script src="/js/main.js" defer></script>
<link rel='shortcut icon' href='/logos/epss-man.ico' type='image/x-icon'>	<link rel="stylesheet" href="/css/index.css">
	<script src="js/jquery.visible.min.js" defer></script>
	<title>EPSS | Home</title>
</head>

<body class="body-font">
	<link rel="stylesheet" href="css/nav.css">
<header id="hd" class="sticky-top">
	<nav class="navbar navbar-expand-lg bg-white navbar-light shadow-sm" id="mnNav">
		<div class="container-fluid">
			<a class="navbar-brand d-flex align-items-center p-0" href="index.php">
				<!-- <img src="logos/EPSS_sm-light.png" alt="EPSS Logo" id="nvLg"> -->
				<img src="logos/logo.jpg" alt="EPSS Logo" id="nvLg">
			</a>

			<button class="border-0 navbar-toggler" type="button" data-toggle="collapse" data-target="#mnNavCllps">
				<div class="d-flex flex-column">
					<span class="navbar-bar"></span>
					<span class="navbar-bar"></span>
					<span class="navbar-bar"></span>
				</div>
			</button>

			<div id="mnNavCllps" class="collapse navbar-collapse">
				<ul class="navbar-nav heading">
					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="index.php">Home</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="about.php">About</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="services.php">Services</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="news.php">News</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="awards.php">Awards</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="gallery.php">Gallery</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="contact.php">Contact</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<div id="secNav" class="p-1 font-4 d-none d-lg-block bg-dark-blue">
		<div class="container">
			<div class="d-flex justify-content-between">
				<ul id="navContact" class="list-inline mb-0 font-sm">
					<li class="list-inline-item mr-3 text-white">
						<i class="fas fa-phone-alt mr-1 text-warning"></i>
						<a href="tel:+2348060256803" class="text-white">(+234) 806 025 6803</a>
						<span class="mx-1">,</span>
						<a href="tel:+2349062541550" class="text-white">(+234) 906 254 1550</a>
					</li>
					<li class="list-inline-item mr-3">
						<i class="fas fa-envelope mr-1 text-warning"></i>
						<a href="mailto:admin@epsssecurity.com" class="text-white">admin@epsssecurity.com</a>
					</li>
					<li class="list-inline-item mr-3 text-warning">
						<i class="fas fa-map-marker-alt mr-1"></i>
						<a href="https://goo.gl/maps/XododdL2pWfTbjNv8" target="_blank" class="text-white">43B Churchgate street, VI, Lagos</a>
					</li>
				</ul>

				<ul id="navSocial" class="list-inline mb-0 h5">
					<li class="list-inline-item"><a href="https://web.facebook.com/EPSS-Private-Security-Services-LTD-1393945044177997/" class="ease text-light font-sm" aria-label="EPSS on Facebook"><i class="fab fa-facebook-f"></i></a></li>
					<li class="list-inline-item"><a href="http://www.twitter.com/EpssSecurity" class="ease text-light font-sm" aria-label="EPSS on Twitter" title="Twitter"><i class="fab fa-twitter-square"></i></a></li>
					<li class="list-inline-item"><a href="https://www.instagram.com/epsssecurity" class="ease text-light font-sm" aria-label="EPSS on Instagram" title="Instagram"><i class="fab fa-instagram"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
</header>
	<div id="homeCarousel" class="carousel slide" data-ride="carousel" data-interval="false">
		<div class="carousel-inner">
			<div class="carousel-item active">
				<div role="banner" class="banner bg-img overlay overlay-black position-relative" style="background-image: url(files/received/1.jpg)" id="bann">
					<div class="container">
						<div class="position-absolute banner-block v-centered">
							<h1 class="font-weight-light heading mb-4 text-white banner-heading" id="bannHd">We offer expert security solutions that work</h1>
							<p class="lead mb-4 text-light">Our duty to our clients is to serve and protect.</p>

							<div>
								<a href="about.php" class="btn btn-warning btn-hover-primary ease px-4 py-3 rounded-0">Learn More</a>
								<a href="contact.php" class="btn btn-outline-light ml-3 px-4 py-3 rounded-0">Contact</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<a class="carousel-control-prev" href="#homeCarousel" data-slide="prev" style="opacity: 0; width:5%">
			<span class="carousel-control-prev-icon"></span>
		</a>
		<a class="carousel-control-next" href="#homeCarousel" data-slide="next" style="opacity: 0; width:5%">
			<span class="carousel-control-next-icon"></span>
		</a>

	</div>

	<section id="about">
		<div class="container-fluid">
			<div class="row flex-md-row-reverse">
				<div class="col-lg-8 p-sm-5 py-4">
					<div class="pl-4 pr-5 pt-3 pt-lg-5">
						<h1 class="font-sm h6 heading mb-3 sub-title d-flex align-items-center text-primary text-uppercase">Who Are We</h1>

						<div class="font-weight-normal h3 heading mb-5">Focused on the all-round protection of what matters to you</div>

						<div>
							<p>EPSS Security is a Nigerian-based private security company, dedicated to providing on-site security guard services and mobile patrol services for commercial and residential properties. Our thoroughly vetted and trained security officers work as armed or unarmed guards, uniformed and plain clothed, on foot, or vehicle patrol.</p>
							<p>We deliver quick and efficient services you need, aimed at fulfilling the unique needs of your business and protecting your people and property. We provide value to you by understanding your requirements and providing receptive security servcies at national level with the benefit of our comprehensive support network.</p>
							<a href="about.php" class="btn btn-primary btn-hover-warning ease px-4 py-3 rounded-0">Read More</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 bg-dark-blue p-5">
					<ul aria-label="Features" class="list-unstyled mb-0" id="featuresList">
						<li class="ease p-lg-4 p-5 position-relative z-1">
							<div class="heading h5 text-white">Licensed & Approved</div>
							<div class="d-flex">
								<p class="mb-0 text-white-50">We are government-approved and our staff are licensed and trained</p>
								<i class="fa-solid fa-award ease"></i>
							</div>
						</li>

						<li class="ease p-lg-4 p-5 position-relative z-1">
							<div class="heading h5 text-white">Professional</div>
							<div class="d-flex">
								<p class="mb-0 text-white-50">Our staff are trained to deliver efficiently, respectfully and on time</p>
								<i class="fa-regular fa-handshake ease"></i>
							</div>
						</li>

						<li class="ease p-lg-4 p-5 position-relative z-1">
							<div class="heading h5 text-white">Cost-Effective</div>
							<div class="d-flex">
								<p class="mb-0 text-white-50">We protect what you entrust to us without draining your finances</p>
								<i class="fa-solid fa-piggy-bank ease"></i>
							</div>
						</li>

						<li class="ease p-lg-4 p-5 position-relative z-1">
							<div class="heading h5 text-white">Customer Support</div>
							<div class="d-flex">
								<p class="mb-0 text-white-50">We handle your complaints and questions to see to your satisfaction</p>
								<i class="fa-solid fa-headset ease"></i>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section>

	<section id="services" class="bg-light py-5">
		<div class="container pb-5">
			<h1 class="font-sm h6 heading mb-5 sub-title d-flex align-items-center text-black text-uppercase">Our Services</h1>

			<div class='row mt-4'><div class='col-lg-4 mb-4 mb-lg-0'>
				<div class='ease px-5 py-5 service-card text-left h-100 z-1 position-relative overflow-hidden'>
					<i class='fa-solid fa-shield-blank mt-3'></i>
					<div class='h5 heading font-weight-normal mb-4 mt-5 z-1'>
						<a href='services.php#service_1' class='ease text-reset text-decoration-none'>Guard Services</a>
					</div>
					<p class='service-text text-black-50'>Armed and unarmed guard services, close executive protection and vehicle escorts.</p>
					<a href='services.php#service_1' class='btn btn-sm btn-link d-inline-flex align-items-center ease font-weight-bold'>Read more</a>
				</div>
				</div><div class='col-lg-4 mb-4 mb-lg-0'>
				<div class='ease px-5 py-5 service-card text-left h-100 z-1 position-relative overflow-hidden'>
					<i class='fa-solid fa-bell mt-3'></i>
					<div class='h5 heading font-weight-normal mb-4 mt-5 z-1'>
						<a href='services.php#service_2' class='ease text-reset text-decoration-none'>Electronic Surveillance</a>
					</div>
					<p class='service-text text-black-50'>E-surveillance technologies allow a broader and more secure range of security services.</p>
					<a href='services.php#service_2' class='btn btn-sm btn-link d-inline-flex align-items-center ease font-weight-bold'>Read more</a>
				</div>
				</div><div class='col-lg-4 mb-4 mb-lg-0'>
				<div class='ease px-5 py-5 service-card text-left h-100 z-1 position-relative overflow-hidden'>
					<i class='fa-solid fa-ship mt-3'></i>
					<div class='h5 heading font-weight-normal mb-4 mt-5 z-1'>
						<a href='services.php#service_3' class='ease text-reset text-decoration-none'>Marine & Port Security</a>
					</div>
					<p class='service-text text-black-50'>Offshore and in-transit operations for ports, ships and shipping terminals.</p>
					<a href='services.php#service_3' class='btn btn-sm btn-link d-inline-flex align-items-center ease font-weight-bold'>Read more</a>
				</div>
				</div></div><div class='row mt-4'><div class='col-lg-4 mb-4 mb-lg-0'>
				<div class='ease px-5 py-5 service-card text-left h-100 z-1 position-relative overflow-hidden'>
					<i class='fa-solid fa-bus-simple mt-3'></i>
					<div class='h5 heading font-weight-normal mb-4 mt-5 z-1'>
						<a href='services.php#service_4' class='ease text-reset text-decoration-none'>Logistics</a>
					</div>
					<p class='service-text text-black-50'>Services that support your backend operations such as accomodation and transportation.</p>
					<a href='services.php#service_4' class='btn btn-sm btn-link d-inline-flex align-items-center ease font-weight-bold'>Read more</a>
				</div>
				</div><div class='col-lg-4 mb-4 mb-lg-0'>
				<div class='ease px-5 py-5 service-card text-left h-100 z-1 position-relative overflow-hidden'>
					<i class='fa-solid fa-crosshairs mt-3'></i>
					<div class='h5 heading font-weight-normal mb-4 mt-5 z-1'>
						<a href='services.php#service_5' class='ease text-reset text-decoration-none'>Assessment & Audit</a>
					</div>
					<p class='service-text text-black-50'>Sweeps and risk assessments to analyse weaknesses and security gaps.</p>
					<a href='services.php#service_5' class='btn btn-sm btn-link d-inline-flex align-items-center ease font-weight-bold'>Read more</a>
				</div>
				</div>		</div>
	</section>

	<section id="stats">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-10 col-md-11 col-12 mt-n5">
										<div class="row bg-primary text-center py-3">
						<div class="col-md-3">
							<div class="d-flex flex-column justify-content-center align-items-center p-5">
								<div class="h1 heading font-weight-bold text-white" data-stat-count="19">0</div>
								<p class="mb-0 text-light">Years of Experience</p>
							</div>
						</div>
						<div class="col-md-3">
							<div class="d-flex flex-column justify-content-center align-items-center p-5">
								<div class="h1 heading font-weight-bold text-white" data-stat-count="2">0</div>
								<p class="mb-0 text-light">National Offices</p>
							</div>
						</div>
						<div class="col-md-3">
							<div class="d-flex flex-column justify-content-center align-items-center p-5">
								<div class="h1 heading font-weight-bold text-white" data-stat-count="40" data-stat-estimate="true">0</div>
								<p class="mb-0 text-light">Client firms</p>
							</div>
						</div>
						<div class="col-md-3">
							<div class="d-flex flex-column justify-content-center align-items-center p-5">
								<div class="h1 heading font-weight-bold text-white" data-stat-count="462" data-stat-estimate="true">0</div>
								<p class="mb-0 text-light">Guards</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="testimonials" class="py-5">
		<div class="container py-4">
			<div class="row">
				<div class="col-lg-5">
					<div class="">
						<h1 class="font-sm h6 heading mb-3 sub-title d-flex align-items-center text-warning text-uppercase">Testimonials</h1>

						<div class="font-weight-normal h3 heading mb-4">Our clients are satisfied with what we do</div>

						<p class="lead">To ensure you are happy with what we do, we employ solutions that are tailored to meet your needs and execute them efficiently.</p>
					</div>
				</div>

				<div class="col-lg-6 offset-lg-1 mt-3 mt-lg-0">
					<div id='carouselSlide' class='carousel slide' data-ride='carousel'>
			<div class='mb-3'></div><div class='carousel-inner px-sm-5 px-4'><div class='carousel-item active'>
					<div class='h3 mb-3 text-black-50'><i class='fa-solid fa-quote-left'></i></div>
					<blockquote>
						<p>It is our pleasure to recommend EPSS Private Security Services Ltd to you for good security job. About 5 years we have contracted with them, it has been a formidable partnership in keeping staff residence and office complex clear of any question on security. OMAK deeply values their professional Services.</p>
						<div>
							<div class='testimonial-author font-weight-bold'>Captain Karimu</div>
							<div class='text-black-50 text-bar d-flex align-items-center'>Managing Director, OMAK Maritime Ltd</div>
						</div>
					</blockquote>
				</div></div></div>				</div>
			</div>
	</section>

	<section id="news" class="py-4">
		<h1 class="font-sm h6 heading mb-5 sub-title d-flex align-items-center text-primary text-uppercase justify-content-center">News</h1>
		<div class="container-fluid">
			<div class="row">
				<article class='align-items-stretch col-lg-4 d-flex flex-column px-0 news-item ' aria-labelledby='newsExcerptTitle_13'><a href='news.php?id=13' class='ease'><div class='media bg-img' style='background-image: url(/files/news/0e63937cca318b915716e2c44c6098c0.jpg);'><img src='/files/news/0e63937cca318b915716e2c44c6098c0.jpg' class='sr-only' alt=''/></div></a>
					<div class='p-5 news-body flex-fill'>
						<p class='font-sm mb-4 mt-2 text-black-50 text-bar d-flex align-items-center text-uppercase' aria-label='News Date'>18 May 2022</p>
						<h1 class='font-weight-normal h5 heading mb-3' id='newsExcerptTitle_13'>EPSS Marks 15th Anniversary / Webinar</h1>
						<p class='article-body'>To mark the 15th-year anniversary of EPSS Private Security Services Ltd, EPSS will be hosting an online webinar on </p><p class='font-italic font-sm text-black-50'>Event for <span class='font-weight-bold'>19 May, 2022 - 2:00am</span></p>
						<a href='news.php?id=13' class='btn btn-sm btn-link px-0 d-inline-flex align-items-center ease font-weight-bold'>Read more</a>
					</div>
				</article>
							</div>
			<div class="mt-4 text-right">
				<a href="news.php" class="btn btn-dark px-4 py-3 rounded-0">All News<i class="fa-solid fa-arrow-right ml-2"></i></a>
			</div>
		</div>
	</section>

	<footer class="pb-3 pt-3 pt-sm-5 px-2 px-sm-5 text-white" style="background-color: #111;">
	<div class="container text-center">
		<div class="mb-4">
			<div class="heading h4" id="footerHd">Let's hear from you</div>
			<div class="mb-3 text-white-50" id="footerCtcTxt">Reach us for questions, complaints or to get started with us.</div>
			<a class="btn btn-outline-warning px-3 rounded-pill" href="contact.php">Contact us</a>

			<div class="d-md-none mt-3">
				<ul id="footerSocials" class="pl-0 list-inline h4">
					<li class="list-inline-item"><a href="https://web.facebook.com/EPSS-Private-Security-Services-LTD-1393945044177997/" class="ease text-light" aria-label="EPSS on Facebook"><i class="fab fa-facebook-f"></i></a></li>
					<li class="list-inline-item"><a href="http://www.twitter.com/EpssSecurity" class="ease text-light" aria-label="EPSS on Twitter" title="Twitter"><i class="fab fa-twitter-square"></i></a></li>
					<li class="list-inline-item"><a href="https://www.instagram.com/epsssecurity" class="ease text-light" aria-label="EPSS on Instagram" title="Instagram"><i class="fab fa-instagram"></i></a></li>
				</ul>
			</div>
		</div>

		<div class="border-secondary border-top font-sm pt-3 pt-sm-4">
			<div><span>&copy;</span> <span>2026</span> <span>EPSS</span> <span>All rights reserved</span></div>
			<div class="font-sm text-secondary">Developed by Soget | <a href="admin/index.php" class="text-muted text-decoration-line" target="_blank">Admin only</a></div>
		</div>
	</div>
</footer>

<style>
	@media screen and (max-width: 425px) {
		#footerHd {
			font-size: 1.25rem;
		}

		#footerCtcTxt {
			font-size: 0.9rem;
		}
	}
</style></body>

<script>
	$(document).ready(function() {
		$('#mnNav .nav-link[href="index.php"]').addClass('active');

		var scrollTimeout = null;
		const windowHeight = window.innerHeight;
		const scrollHeigt = $('body').height();

		$(window).scroll(function() {
			clearTimeout(scrollTimeout);

			scrollTimeout = setTimeout(function() {
				updateStats();
			}, 50);
		});

		updateStats();

		function updateStats() {
			if (isInViewport(document.getElementById('stats'))) {
				$('[data-stat-count]:not([data-stat-loaded])').each(function() {
					var $this = $(this);
					var to = parseInt($this.attr('data-stat-count'));
					var estimate = $this.attr('data-stat-estimate') === 'true';

					if(!to) return;

					var count = 0;

					var statInterval = null;

					if (to < 10) {
						interval = 100;
					} else if (to < 100) {
						interval = 50;
					} else {
						interval = 5;
					}

					var updateStatCount = () => {
						$this.html(estimate ? `${count}<sup>+</sup>` : count);
						if (count == to) clearInterval(statInterval);
						++count;
					};

					statInterval = setInterval(updateStatCount, interval);

					$this.attr('data-stat-loaded', 'true');
					$(window).off('scroll');
				});
			}
		}
	})
</script>

</html>