<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/main.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<script src="/js/main.js" defer></script>
<link rel='shortcut icon' href='/logos/epss-man.ico' type='image/x-icon'>	<title>EPSS | Contact</title>
	<link rel="stylesheet" href="/css/contact.css">
</head>

<body class="body-font">
	<link rel="stylesheet" href="css/nav.css">
<header id="hd" class="sticky-top">
	<nav class="navbar navbar-expand-lg bg-white navbar-light shadow-sm" id="mnNav">
		<div class="container-fluid">
			<a class="navbar-brand d-flex align-items-center p-0" href="index.php">
				<!-- <img src="logos/EPSS_sm-light.png" alt="EPSS Logo" id="nvLg"> -->
				<img src="logos/logo.jpg" alt="EPSS Logo" id="nvLg">
			</a>

			<button class="border-0 navbar-toggler" type="button" data-toggle="collapse" data-target="#mnNavCllps">
				<div class="d-flex flex-column">
					<span class="navbar-bar"></span>
					<span class="navbar-bar"></span>
					<span class="navbar-bar"></span>
				</div>
			</button>

			<div id="mnNavCllps" class="collapse navbar-collapse">
				<ul class="navbar-nav heading">
					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="index.php">Home</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="about.php">About</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="services.php">Services</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="news.php">News</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="awards.php">Awards</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="gallery.php">Gallery</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="contact.php">Contact</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<div id="secNav" class="p-1 font-4 d-none d-lg-block bg-dark-blue">
		<div class="container">
			<div class="d-flex justify-content-between">
				<ul id="navContact" class="list-inline mb-0 font-sm">
					<li class="list-inline-item mr-3 text-white">
						<i class="fas fa-phone-alt mr-1 text-warning"></i>
						<a href="tel:+2348060256803" class="text-white">(+234) 806 025 6803</a>
						<span class="mx-1">,</span>
						<a href="tel:+2349062541550" class="text-white">(+234) 906 254 1550</a>
					</li>
					<li class="list-inline-item mr-3">
						<i class="fas fa-envelope mr-1 text-warning"></i>
						<a href="mailto:admin@epsssecurity.com" class="text-white">admin@epsssecurity.com</a>
					</li>
					<li class="list-inline-item mr-3 text-warning">
						<i class="fas fa-map-marker-alt mr-1"></i>
						<a href="https://goo.gl/maps/XododdL2pWfTbjNv8" target="_blank" class="text-white">43B Churchgate street, VI, Lagos</a>
					</li>
				</ul>

				<ul id="navSocial" class="list-inline mb-0 h5">
					<li class="list-inline-item"><a href="https://web.facebook.com/EPSS-Private-Security-Services-LTD-1393945044177997/" class="ease text-light font-sm" aria-label="EPSS on Facebook"><i class="fab fa-facebook-f"></i></a></li>
					<li class="list-inline-item"><a href="http://www.twitter.com/EpssSecurity" class="ease text-light font-sm" aria-label="EPSS on Twitter" title="Twitter"><i class="fab fa-twitter-square"></i></a></li>
					<li class="list-inline-item"><a href="https://www.instagram.com/epsssecurity" class="ease text-light font-sm" aria-label="EPSS on Instagram" title="Instagram"><i class="fab fa-instagram"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
</header>
	<div role="banner" class="banner bg-img overlay overlay-black position-relative" style="background-image: url(files/received/26-1.jpg)" id="bann">
		<div class="container">
			<div class="position-absolute banner-block v-centered">
				<h1 class="font-sm h6 heading mb-3 sub-title d-flex align-items-center text-warning text-uppercase">Contact</h1>
				<h2 class="font-weight-light heading mb-4 text-white banner-heading" id="bannHd">Round-the-clock support</h2>
			</div>
		</div>
	</div>

	<section id="contact" class="py-4 py-sm-5">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-5" id="contactDetails">
					<ul class="list-unstyled">
						<li>
							<ul id="footerSocials" class="pl-4 list-inline h5 mb-0">
								<li class="list-inline-item"><a href="https://web.facebook.com/EPSS-Private-Security-Services-LTD-1393945044177997/" class="ease text-reset" aria-label="EPSS on Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="list-inline-item"><a href="http://www.twitter.com/EpssSecurity" class="ease text-reset" aria-label="EPSS on Twitter" title="Twitter"><i class="fab fa-twitter-square"></i></a></li>
								<li class="list-inline-item"><a href="https://www.instagram.com/epsssecurity" class="ease text-reset" aria-label="EPSS on Instagram" title="Instagram"><i class="fab fa-instagram"></i></a></li>
							</ul>
						</li>

						<li>
							<div class="d-flex align-items-center">
								<div class="mr-3"><i class="fa-solid fa-phone" style="color: var(--orange)"></i></div>
								<div>
									<div class="text-uppercase text-muted small heading">Phone</div>
									<p class="mb-0">
										<a href="tel:+2348060256803" class="text-reset">+234 806 025 6803</a>
										<a href="tel:+2349062541550" class="text-reset">+234 906 254 1550</a>
									</p>
								</div>
							</div>
						</li>

						<li>
							<div class="d-flex align-items-center">
								<div class="mr-3"><i class="fa-regular fa-envelope" style="color: var(--red)"></i></div>
								<div>
									<div class="text-uppercase text-muted small heading">Email</div>
									<p class="mb-0"><a href="mailto:admin@epsssecurity.com" class="text-reset">admin@epsssecurity.com</a></p>
								</div>
							</div>
						</li>

						<li>
							<div class="d-flex align-items-center">
								<div class="mr-3"><i class="fa-solid fa-location-dot" style="color: var(--pink)"></i></div>
								<div>
									<div class="text-uppercase text-muted small heading">Office</div>
									<address class="mb-1"><b>Port Harcourt:</b> Plot 80B, Peter Odili Road, Trans-Amadi Industrial Layout</address>
									<address class="mb-0"><b>Lagos:</b> 43B Churchgate street, Victoria Island</address>
								</div>
							</div>
						</li>

						<li>
							<div class="d-flex align-items-center">
								<div class="mr-3"><i class="fa-regular fa-calendar-days" style="color: var(--purple)"></i></div>
								<div>
									<div class="text-uppercase text-muted small heading">Open Days</div>
									<p class="mb-0">Monday - Sunday</p>
								</div>
							</div>
						</li>

						<li>
							<div class="d-flex align-items-center">
								<div class="mr-3"><i class="fa-regular fa-clock" style="color: var(--indigo)"></i></div>
								<div>
									<div class="text-uppercase text-muted small heading">Visiting Hours</div>
									<p class="mb-0">8am - 5pm</p>
								</div>
							</div>
						</li>
					</ul>
				</div>

				<div class="col-md-7 mt-md-0 mt-3">
					<form action="" id="contactForm">
						<div class="form-group pb-3">
							<input type="text" class="form-control form-control-lg px-md-4 px-3 py-3 rounded-0" id="name" name="n" placeholder="Name" aria-label="Name" required>
						</div>

						<div class="form-group pb-3">
							<input type="email" class="form-control form-control-lg px-md-4 px-3 py-3 rounded-0" id="email" name="e" placeholder="Email" aria-label="Your email address" required>
						</div>

						<div class="form-group pb-3">
							<input type="tel" class="form-control form-control-lg px-md-4 px-3 py-3 rounded-0" id="phone" name="p" placeholder="Phone number" aria-label="Your phone number" required>
						</div>

						<div class="form-group pb-3">
							<input type="text" class="form-control form-control-lg px-md-4 px-3 py-3 rounded-0" id="subject" name="s" placeholder="Reason for inquiry" aria-label="Reason for inquiry" required>
						</div>

						<div class="form-group pb-3">
							<textarea name="m" id="message" rows="4" style="resize: none;" placeholder="Message" aria-label="Message" class="form-control form-control-lg px-md-4 px-3 py-3 rounded-0" required></textarea>
						</div>

						<div id="contactMessage"></div>

						<div class="form-group mb-0 pt-md-3">
							<button type="submit" class="btn btn-primary ease px-4 py-3 rounded-0">Submit Message</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</section>

	<footer class="pb-3 pt-3 pt-sm-5 px-2 px-sm-5 text-white" style="background-color: #111;">
	<div class="container text-center">
		<div class="mb-4">
			<div class="heading h4" id="footerHd">Let's hear from you</div>
			<div class="mb-3 text-white-50" id="footerCtcTxt">Reach us for questions, complaints or to get started with us.</div>
			<a class="btn btn-outline-warning px-3 rounded-pill" href="contact.php">Contact us</a>

			<div class="d-md-none mt-3">
				<ul id="footerSocials" class="pl-0 list-inline h4">
					<li class="list-inline-item"><a href="https://web.facebook.com/EPSS-Private-Security-Services-LTD-1393945044177997/" class="ease text-light" aria-label="EPSS on Facebook"><i class="fab fa-facebook-f"></i></a></li>
					<li class="list-inline-item"><a href="http://www.twitter.com/EpssSecurity" class="ease text-light" aria-label="EPSS on Twitter" title="Twitter"><i class="fab fa-twitter-square"></i></a></li>
					<li class="list-inline-item"><a href="https://www.instagram.com/epsssecurity" class="ease text-light" aria-label="EPSS on Instagram" title="Instagram"><i class="fab fa-instagram"></i></a></li>
				</ul>
			</div>
		</div>

		<div class="border-secondary border-top font-sm pt-3 pt-sm-4">
			<div><span>&copy;</span> <span>2026</span> <span>EPSS</span> <span>All rights reserved</span></div>
			<div class="font-sm text-secondary">Developed by Soget | <a href="admin/index.php" class="text-muted text-decoration-line" target="_blank">Admin only</a></div>
		</div>
	</div>
</footer>

<style>
	@media screen and (max-width: 425px) {
		#footerHd {
			font-size: 1.25rem;
		}

		#footerCtcTxt {
			font-size: 0.9rem;
		}
	}
</style></body>

<script>
	$(document).ready(function() {
		$('#mnNav .nav-link[href="contact.php"]').addClass('active');

		function formError() {
			removeAlertOnInput();
			$('#contactMessage').html(`<div class="alert alert-danger font-4 rounded-0" role="alert">Couldn't submit your response. Try again later.</div>`);
		}

		function removeAlertOnInput() {
			$('#contactForm .form-control').on('input', function() {
				$('#contactMessage').empty();
				$('#contactForm .form-control').off('input');
			})
		}

		$('#contactForm').submit(function(e) {
			e.preventDefault();

			var s = $(this).find(':submit');

			if (s.is('[disabled]')) return;

			try {
				s.prepend('<i class="fa-solid fa-spinner mr-2 fa-spin"></i>');
				s.attr('disabled', 'disabled');

				var o = {a: 'set'};
				$('#contactForm .form-control').each(function() {
					if (!this.value) throw new Error('required field is not provided');

					o[this.name] = this.value;
				});

				$.post('/scripts/_contacts.php', o, function(d, s) {
					try {
						if (s !== 'success') throw new Error('Ajax failed; status: ' + s);

						if (d !== 'true') throw new Error('contact failed; data: ' + d);

						removeAlertOnInput();
						$('#contactMessage').html(`<div class="alert alert-success font-4 rounded-0" role="alert">We've submitted your message. We'll write you back shortly.</div>`);

						$('#contactForm').trigger('reset');
					} catch (error) {
						console.error(error);
						formError();
					} finally {
						$('#contactForm :submit').removeAttr('disabled').text('Submit Message');
					}
				})
			} catch (error) {
				console.log(error);
				s.removeAttr('disabled').text('Submit Message');
				formError();
			}
		});
	})
</script>

</html>