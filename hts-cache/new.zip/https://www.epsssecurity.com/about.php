
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/main.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<script src="/js/main.js" defer></script>
<link rel='shortcut icon' href='/logos/epss-man.ico' type='image/x-icon'>	<title>EPSS | About</title>
	<link rel="stylesheet" href="css/about.css">
</head>

<body class="body-font">
	<link rel="stylesheet" href="css/nav.css">
<header id="hd" class="sticky-top">
	<nav class="navbar navbar-expand-lg bg-white navbar-light shadow-sm" id="mnNav">
		<div class="container-fluid">
			<a class="navbar-brand d-flex align-items-center p-0" href="index.php">
				<!-- <img src="logos/EPSS_sm-light.png" alt="EPSS Logo" id="nvLg"> -->
				<img src="logos/logo.jpg" alt="EPSS Logo" id="nvLg">
			</a>

			<button class="border-0 navbar-toggler" type="button" data-toggle="collapse" data-target="#mnNavCllps">
				<div class="d-flex flex-column">
					<span class="navbar-bar"></span>
					<span class="navbar-bar"></span>
					<span class="navbar-bar"></span>
				</div>
			</button>

			<div id="mnNavCllps" class="collapse navbar-collapse">
				<ul class="navbar-nav heading">
					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="index.php">Home</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="about.php">About</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="services.php">Services</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="news.php">News</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="awards.php">Awards</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="gallery.php">Gallery</a>
					</li>

					<li class="nav-item mx-4">
						<a class="nav-link position-relative ease px-0" href="contact.php">Contact</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<div id="secNav" class="p-1 font-4 d-none d-lg-block bg-dark-blue">
		<div class="container">
			<div class="d-flex justify-content-between">
				<ul id="navContact" class="list-inline mb-0 font-sm">
					<li class="list-inline-item mr-3 text-white">
						<i class="fas fa-phone-alt mr-1 text-warning"></i>
						<a href="tel:+2348060256803" class="text-white">(+234) 806 025 6803</a>
						<span class="mx-1">,</span>
						<a href="tel:+2349062541550" class="text-white">(+234) 906 254 1550</a>
					</li>
					<li class="list-inline-item mr-3">
						<i class="fas fa-envelope mr-1 text-warning"></i>
						<a href="mailto:admin@epsssecurity.com" class="text-white">admin@epsssecurity.com</a>
					</li>
					<li class="list-inline-item mr-3 text-warning">
						<i class="fas fa-map-marker-alt mr-1"></i>
						<a href="https://goo.gl/maps/XododdL2pWfTbjNv8" target="_blank" class="text-white">43B Churchgate street, VI, Lagos</a>
					</li>
				</ul>

				<ul id="navSocial" class="list-inline mb-0 h5">
					<li class="list-inline-item"><a href="https://web.facebook.com/EPSS-Private-Security-Services-LTD-1393945044177997/" class="ease text-light font-sm" aria-label="EPSS on Facebook"><i class="fab fa-facebook-f"></i></a></li>
					<li class="list-inline-item"><a href="http://www.twitter.com/EpssSecurity" class="ease text-light font-sm" aria-label="EPSS on Twitter" title="Twitter"><i class="fab fa-twitter-square"></i></a></li>
					<li class="list-inline-item"><a href="https://www.instagram.com/epsssecurity" class="ease text-light font-sm" aria-label="EPSS on Instagram" title="Instagram"><i class="fab fa-instagram"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
</header>
	<div role="banner" class="banner bg-img overlay overlay-black position-relative" style="background-image: url(files/received/9.jpg)" id="bann">
		<div class="container">
			<div class="position-absolute banner-block v-centered">
				<h1 class="font-sm h6 heading mb-3 sub-title d-flex align-items-center text-warning text-uppercase">About</h1>
				<h2 class="font-weight-light heading mb-4 text-white banner-heading" id="bannHd">We believe in low-profile, risk-based and threat-driven solutions.</h2>
			</div>
		</div>
	</div>

	<section id="introduction">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-8 pb-4 pb-md-0">
					<div class="p-md-5 px-3 py-4">
						<h1 class="font-sm h6 heading mb-3 sub-title d-flex align-items-center text-primary text-uppercase">Who we are</h1>
						<div class="font-weight-normal h3 heading mb-5">A security agency you can trust</div>

						<p>EPSS Security is a leading security and facility services company. We provide proactive security services and cutting-edge smart technology to deliver evolving, tailored solutions that allow our clients to focus on their core business. Our excellence starts with our local leadership and local presence.</p>

						<p>Operating under Injaz Limited, across all 36 states in Nigeria, our experienced team helps deliver our promise nationwide: protecting people and things that matter to you.

						<div class="heading h5 text-black">Mission Statement</div>
						<p class="font-italic">To plan, develop and facilitate innovative security management procedures, fire and safety preparedness.</p>

						<div class="heading h5 text-black">Vision Statement</div>
						<ul class="font-italic pl-4">
							<li>To constantly provide innovative and comprehensive security solutions.</li>
							<li>To operate within a strict moral, ethical and legal code.</li>
							<li>To help develop effective, optimal operational methodologies that increase daily levels of security in our environs.</li>
							<li>A strong drve to ensure quality, professionalism and integrity per excellence.</li>
						</ul>
					</div>
				</div>

				<div class="col-md-4 mt-n5 mb-n5">
					<div class="bg-img h-100 overlay position-relative bg-fixed" id="introImg" style="background-image: url(files/received/11-1.jpg);"></div>
				</div>
			</div>
		</div>
	</section>

	<section id="process" class="py-5 bg-dark-blue">
		<div class="container text-center text-white position-relative z-1">
			<h1 class="font-sm h6 heading mb-3 sub-title d-flex align-items-center text-warning text-uppercase justify-content-center mt-4 mt-sm-0">How we work</h1>
			<div class="font-weight-normal h3 heading mb-4">The process that gets the job done</div>

			<ol class="font-4 mx-auto text-left w-75 mb-0 pl-5 pl-sm-0">
				<li class="mb-3 pl-3">
					<div class="body-font">
						<p class="heading h5">Asset evaluation</p>
						<div>We identify properties and people to be protected, and draw information including data on our client's operations, plans and strategies. We also determine the security level of all assests under our care. Our team of Security Mitigators conduct a Risk Assessment to ascertain the vulnerability of the location, then put together a documentation on the risk analysis and recommendations.</div>
					</div>
				</li>

				<li class="mb-3 pl-3">
					<div class="body-font">
						<p class="heading h5">Deployment of Operatives</p>
						<div>After the Risk Assessment and Analysis are reviewed and agreed by both the Principal (owner of the location) and the Vendor (Security Company), the guards will be deployed to perform their duties.</div>
					</div>
				</li>

				<li class="mb-3 pl-3">
					<div class="body-font">
						<p class="heading h5">Security practices</p>
						<div>We draft and plan asset clarification practices, risk assessment and acceptance, asset ownership, asset handling responsibilities, policies regarding mishandling assests, security violations and how they are handled and security audits. The operatives are monitored by our team of supervisors and Operation Managers through physical visition or phone/video calls. Operative training is done either onsite or remotely. Operatives are then equipped with all necessary security apparatus.</div>
					</div>
				</li>

				<li class="pl-3">
					<div class="body-font">
						<p class="heading h5">Evaluation</p>
						<div>For optimal delivery, we reassess security management in case of rampant security violations, structural change in the client organisation, change in environment, change in staff or gadgets used or change in budget. Our Customer Care department remains in touch with the client, and the Guards Feedback Form is sent out to the guards to enquire of their welfare.</div>
					</div>
				</li>
			</ol>

			<i class="fas fa-tasks shadow-icon text-white position-absolute z-n1" id="introducton2Icon"></i>
		</div>
	</section>

	<section id="clients" class="py-4 py-sm-5">
		<div class="container">
			<h1 class="font-sm h6 heading mb-3 sub-title d-flex align-items-center text-primary text-uppercase">Our Reputable Clients</h1>
			<div class="font-weight-normal h3 heading mb-4">We promised and delivered</div>
			<p>EPSS Private Security Company is trusted by dozens of businesses in Nigeria.</p>

			<div class="pt-4 pb-4">
				<div class='row mt-3'><div class='col-md-3 mb-3 mb-md-0'>
					<div class='align-items-center border border-light d-flex h-100 justify-content-center p-5 position-relative rounded-lg client-im'>
						<div class='client-icon'><img class='img-fluid' src='/files/clients/864306ffe23b8ea4c566330b1073bd60.jpg' alt='Exxon Mobil'></div>
						<div class='client-desc ease p-4 position-absolute rounded-lg d-flex flex-column justify-content-between'><div class='heading mb-0 client-ttl ease font-weight-bold'>Exxon Mobil</div></div>
					</div>
				</div><div class='col-md-3 mb-3 mb-md-0'>
					<div class='align-items-center border border-light d-flex h-100 justify-content-center p-5 position-relative rounded-lg client-im'>
						<div class='client-icon'><img class='img-fluid' src='/files/clients/fd4e37db11265ed17627a220812310a3.jpg' alt='Nigerian Maritime Administration &amp; Safety Agency'></div>
						<div class='client-desc ease p-4 position-absolute rounded-lg d-flex flex-column justify-content-between'><div class='heading mb-0 client-ttl ease font-weight-bold'>Nigerian Maritime Administration &amp; Safety Agency</div></div>
					</div>
				</div><div class='col-md-3 mb-3 mb-md-0'>
					<div class='align-items-center border border-light d-flex h-100 justify-content-center p-5 position-relative rounded-lg client-im'>
						<div class='client-icon'><img class='img-fluid' src='/files/clients/e8a797f9d0e0cbe089b8848eb4b42fe5.jpg' alt='Nigerian National Petroleum Corporation'></div>
						<div class='client-desc ease p-4 position-absolute rounded-lg d-flex flex-column justify-content-between'><div class='heading mb-0 client-ttl ease font-weight-bold'>Nigerian National Petroleum Corporation</div></div>
					</div>
				</div><div class='col-md-3 mb-3 mb-md-0'>
					<div class='align-items-center border border-light d-flex h-100 justify-content-center p-5 position-relative rounded-lg client-im'>
						<div class='client-icon'><img class='img-fluid' src='/files/clients/d0546e62838e1cd4767a9c4d62a55c45.jpg' alt='Hamilton Technologies'></div>
						<div class='client-desc ease p-4 position-absolute rounded-lg d-flex flex-column justify-content-between'><div class='heading mb-0 client-ttl ease font-weight-bold'>Hamilton Technologies</div></div>
					</div>
				</div></div><div class='row mt-3'><div class='col-md-3 mb-3 mb-md-0'>
					<div class='align-items-center border border-light d-flex h-100 justify-content-center p-5 position-relative rounded-lg client-im'>
						<div class='client-icon'><img class='img-fluid' src='/files/clients/50ea01b187095e53ca2767ce38aed504.jpg' alt='Omak Maritime'></div>
						<div class='client-desc ease p-4 position-absolute rounded-lg d-flex flex-column justify-content-between'><div class='heading mb-0 client-ttl ease font-weight-bold'>Omak Maritime</div></div>
					</div>
				</div><div class='col-md-3 mb-3 mb-md-0'>
					<div class='align-items-center border border-light d-flex h-100 justify-content-center p-5 position-relative rounded-lg client-im'>
						<div class='client-icon'><img class='img-fluid' src='/files/clients/e7b4595a462dffc7cdc437427a74a74c.jpeg' alt='Shell'></div>
						<div class='client-desc ease p-4 position-absolute rounded-lg d-flex flex-column justify-content-between'><div class='heading mb-0 client-ttl ease font-weight-bold'>Shell</div></div>
					</div>
				</div></div>			</div>
		</div>
	</section>

	<div class="banner bg-img bg-position-bottom overlay overlay-black position-relative" id="divider" style="height: 10rem;"></div>

	<section id="management" class="py-4 py-sm-5 position-relative">
		<div class="container-fluid">
			<div class="text-center">
				<h1 class="font-sm h6 heading mb-3 sub-title d-flex align-items-center text-primary text-uppercase justify-content-center">Our team</h1>
				<div class="font-weight-normal h3 heading mb-4">The faces behind our success</div>
			</div>

			<div class="row pt-sm-4">
				<div class='col-md-3'><ul class='nav nav-pills flex-sm-column align-items-center' id='mgtNav'><li class='mt-sm-3 mx-2 mx-sm-0 nav-item'>
					<a class='nav-link bg-transparent active p-0' data-toggle='pill' href='#mgt_1'>
						<div class='position-relative bg-img bg-light border border-light overlay ease mgt-img rounded-circle' aria-labelledby='mgt_1_Ttl' style='background-image: url(/files/team/mgt_1.jpg);' id='mgt_nav_img_1' aria-describedby='mgt_1_Pos'></div>
					</a>
				</li><li class='mt-sm-3 mx-2 mx-sm-0 nav-item'>
					<a class='nav-link bg-transparent  p-0' data-toggle='pill' href='#mgt_2'>
						<div class='position-relative bg-img bg-light border border-light overlay ease mgt-img rounded-circle' aria-labelledby='mgt_2_Ttl' style='background-image: url(/files/team/mgt_2.jpg);' id='mgt_nav_img_2' aria-describedby='mgt_2_Pos'></div>
					</a>
				</li><li class='mt-sm-3 mx-2 mx-sm-0 nav-item'>
					<a class='nav-link bg-transparent  p-0' data-toggle='pill' href='#mgt_3'>
						<div class='position-relative bg-img bg-light border border-light overlay ease mgt-img rounded-circle' aria-labelledby='mgt_3_Ttl' style='background-image: url(/files/team/mgt_3.jpg);' id='mgt_nav_img_3' aria-describedby='mgt_3_Pos'></div>
					</a>
				</li></ul></div><div class='col-md-9'><div class='tab-content mt-4 mt-md-0 pl-2 pl-md-0'><div class='tab-pane active' id='mgt_1'>
					<div class='flex-sm-row-reverse row'>
						<div class='col-sm-4 mb-3 mb-sm-0'>
							<div class='mgt-mn-img position-relative bg-img border border-light' style='background-image: url(/files/team/mgt_1.jpg);'></div>
						</div>
						<div class='col-sm-7'>
							<h1 class='heading h4 text-uppercase mb-1' id='mgt_1_Ttl'>Buduka Johnson</h1>
							<p class='font-weight-normal h6 heading text-secondary' id='mgt_1_Pos'>Managing Director</p>

							<div class='border-light border-top mt-0 mt-md-4 pt-2' style='text-align: justify;'>As a Certified Protection Officer (CPO), Mrs. Buduka Johnson is a very versatile businesswoman with years of experience in the global market and security operations. With a B.Eng (Hons) in Electrical Electronics Engineering and a Master's Degree in Computing and Information Systems from the University of Greenwich, UK, it is easy to understand why she has succeeded in building a formidable team. Her outstanding skill with both local and international partnership gives her an edge to coordinate, organise, and administer the company. Apart from her capacity to develop and market the company's interest in all fields that it covers, she is a member of ASIS International and a professional in the design and implementation of computer-based security systems and operations.</div>
						</div>
					</div>
				</div><div class='tab-pane fade' id='mgt_2'>
					<div class='flex-sm-row-reverse row'>
						<div class='col-sm-4 mb-3 mb-sm-0'>
							<div class='mgt-mn-img position-relative bg-img border border-light' style='background-image: url(/files/team/mgt_2.jpg);'></div>
						</div>
						<div class='col-sm-7'>
							<h1 class='heading h4 text-uppercase mb-1' id='mgt_2_Ttl'>Israel Eno</h1>
							<p class='font-weight-normal h6 heading text-secondary' id='mgt_2_Pos'>Director of Operations</p>

							<div class='border-light border-top mt-0 mt-md-4 pt-2' style='text-align: justify;'>With 20 years postgraduate experience in engineering projects, port facility security services, training and consultancy, Isaac Eno has an academic background in chemical engineering, with other international and local certifications in security Management.
He is a Certified Protection Officer (CPO), Port Facility Security Officer/Ship Security Officer/Company security officer (PFSO/SSO/CSO), BOSIET and a member of ASIS International.
ENO has several years of experience in wastewater, water treatment, facility and security engineering, fire engineering (protection/prevention) projects and operational management (planning, costing, coordinating and implementation).
He has functioned as General Manager in a security and facility management firm for more than ten (10) years. He is a technically-grounded solution provider who ensures that tasks and security operations, monitoring and assessment are implemented to the satisfaction of clients.</div>
						</div>
					</div>
				</div><div class='tab-pane fade' id='mgt_3'>
					<div class='flex-sm-row-reverse row'>
						<div class='col-sm-4 mb-3 mb-sm-0'>
							<div class='mgt-mn-img position-relative bg-img border border-light' style='background-image: url(/files/team/mgt_3.jpg);'></div>
						</div>
						<div class='col-sm-7'>
							<h1 class='heading h4 text-uppercase mb-1' id='mgt_3_Ttl'>Joyce Hilder Biose</h1>
							<p class='font-weight-normal h6 heading text-secondary' id='mgt_3_Pos'>Business Development Manager</p>

							<div class='border-light border-top mt-0 mt-md-4 pt-2' style='text-align: justify;'>Ms Biose is an expert in Business Management and Client-Customer Relationship. With a B.sc (Hon) in Accounting from University of Lagos, her outstanding skills in business development and a career built in various accounting sector, she has an edge to meet and convince clients. Apart from her capacity to develop and market the company's interest in all fields that it covers, she has also proven to be a team leader and motivator.</div>
						</div>
					</div>
				</div></div></div>			</div>
		</div>
	</section>

	<footer class="pb-3 pt-3 pt-sm-5 px-2 px-sm-5 text-white" style="background-color: #111;">
	<div class="container text-center">
		<div class="mb-4">
			<div class="heading h4" id="footerHd">Let's hear from you</div>
			<div class="mb-3 text-white-50" id="footerCtcTxt">Reach us for questions, complaints or to get started with us.</div>
			<a class="btn btn-outline-warning px-3 rounded-pill" href="contact.php">Contact us</a>

			<div class="d-md-none mt-3">
				<ul id="footerSocials" class="pl-0 list-inline h4">
					<li class="list-inline-item"><a href="https://web.facebook.com/EPSS-Private-Security-Services-LTD-1393945044177997/" class="ease text-light" aria-label="EPSS on Facebook"><i class="fab fa-facebook-f"></i></a></li>
					<li class="list-inline-item"><a href="http://www.twitter.com/EpssSecurity" class="ease text-light" aria-label="EPSS on Twitter" title="Twitter"><i class="fab fa-twitter-square"></i></a></li>
					<li class="list-inline-item"><a href="https://www.instagram.com/epsssecurity" class="ease text-light" aria-label="EPSS on Instagram" title="Instagram"><i class="fab fa-instagram"></i></a></li>
				</ul>
			</div>
		</div>

		<div class="border-secondary border-top font-sm pt-3 pt-sm-4">
			<div><span>&copy;</span> <span>2026</span> <span>EPSS</span> <span>All rights reserved</span></div>
			<div class="font-sm text-secondary">Developed by Soget | <a href="admin/index.php" class="text-muted text-decoration-line" target="_blank">Admin only</a></div>
		</div>
	</div>
</footer>

<style>
	@media screen and (max-width: 425px) {
		#footerHd {
			font-size: 1.25rem;
		}

		#footerCtcTxt {
			font-size: 0.9rem;
		}
	}
</style></body>

<script>
	$(document).ready(function() {
		$('#mnNav .nav-link[href="about.php"]').addClass('active');
	})
</script>

</html>