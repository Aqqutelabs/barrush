
<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/main.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<script src="/js/main.js" defer></script>
<link rel='shortcut icon' href='/logos/epss-man.ico' type='image/x-icon'>	<title>EPSS -- Admin | Login</title>
	<link rel="stylesheet" href="/css/admin.css">
	<script src="/js/admin.js"></script>

	<style>
		#logo {
			width: 13rem;
		}
	</style>
</head>

<body class="body-font h-100">
	<div class="container-fluid h-100">
		<div class="row h-100">
			<div class="col-md-6 p-5">
				<div>
					<a href="/index.php">
						<img src="../logos/logo.jpg" alt="EPSS Logo" id="logo">
					</a>
					<div class="font-sm font-weight-bold ml-2 text-uppercase text-black-50">Admin</div>
				</div>

				<form aria-labelledby="loginFormTtl" id="loginForm" class="mt-5">
					<h1 class="h3 text-black font-weight-bold heading mb-4 pb-2" id="loginFormTtl">Log in</h1>

					<div class="form-group">
						<label for="login_user" class="heading font-sm text-muted">Username</label>
						<input type="text" name="u" id="login_user" class="ease form-control py-2 px-3" required>
					</div>

					<div class="form-group">
						<label for="login_pwd" class="heading font-sm text-muted">Password</label>
						<input type="password" name="p" id="login_pwd" class="ease form-control py-2 px-3" required>
						<div class="mt-2 text-muted small">Contact a super administrator if you have forgotten your username/password</div>
					</div>

					<div>
						<button type="submit" class="btn btn-primary px-4 py-2">Log in</button>
					</div>

					<div class="font-weight-bold mt-2 text-danger" id="loginError" role="status"></div>
				</form>
			</div>
			<div class="col-md-6 bg-dark-blue"></div>
		</div>
	</div>
</body>

<script>
	$(document).ready(function() {
		const _login = '/scripts/_login.php';

		// login form is submitted
		$('#loginForm').submit(function(e) {
			e.preventDefault();
			var submit = $('#loginForm :submit');

			if (submit.attr('disabled') !== undefined) return;

			submit.attr('disabled', 'disabled');

			var u = $('#login_user').val();
			var p = $('#login_pwd').val();

			$.post(_login, {
				u: u,
				p: p
			}, function(d, s) {
				try {
					if (s !== 'success') throw new Error('login failed; ajax error status: ' + s);

					if (d === 'false') {
						$('#loginError').text('Invalid username/password');
					} 
					else if(d === 'true'){
						location.assign('index.php');
					}
					else {
						throw new Error('login failed; error: ' + d);
					}
				} catch (error) {
					alert('Something went wrong');
					console.error(error);
				} finally {
					$('#loginForm :submit').removeAttr('disabled');
				}
			})
		});
	});
</script>

</html>